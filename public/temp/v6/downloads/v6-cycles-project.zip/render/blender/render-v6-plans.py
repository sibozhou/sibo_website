"""v6 review views, using the actual imported new-plan geometry."""
from pathlib import Path
import os
import sys

os.environ['QIDONG_VIEWER_VERSION']='v6'
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
assert args and all(a in ['front-day','north-day','front-night','north-night','floor1-day','floor2-day','floor3-day','bathroom-night','bedroom-night'] for a in args)
script=Path(__file__).with_name('render.py')
source=script.read_text()
start=source.index("    elif name.startswith('floor2'):")
end=source.index("    elif name.startswith('west-day'):",start)
source=source[:start]+'''    elif name.startswith('floor'):
        level=int(name[5]);scene.camera.location=plan(14.5,8.35,42)
        scene.camera.rotation_euler=(0,0,angle);scene.camera.data.type='ORTHO';scene.camera.data.ortho_scale=34
        scene.render.resolution_x=1600;scene.render.resolution_y=1100
        for ob in bpy.data.objects:
            if ob.type!='MESH':continue
            group=ob.users_collection[0].name.removeprefix('场景_') if ob.users_collection else ''
            parts=group.split('-')
            if parts[0].isdigit() and int(parts[0])>level or ob.get('屋面') or 'seamRoof' in ob.name or 'ceiling' in group:
                ob.hide_render=True
            if level==3 and parts[0].isdigit() and 0<int(parts[0])<3:ob.hide_render=True
        if level==3:
            # Show the actual arriving stair, without exposing the lower floor's bedrooms through roof voids.
            import numpy as np
            raw=(OUT/'scene.bin').read_bytes();by_id={s['id']:s for s in D['meshes']}
            for sid in sorted({a['source'] for a in D['aliases']}):
                s=by_id[sid]
                if s['level']!=2:continue
                def array(meta,dtype):return np.frombuffer(raw,dtype=dtype,count=meta['bytes']//np.dtype(dtype).itemsize,offset=meta['offset'])
                vertices=array(s['positions'],'<f4').reshape(-1,3).astype(float)
                matrix=np.array(s['matrix']).reshape(4,4).T;vertices=vertices@matrix[:3,:3].T+matrix[:3,3]
                vertices=vertices[:,[0,2,1]]*np.array([1,-1,1]);faces=array(s['indices'],'<u4').reshape(-1,3)
                mesh=bpy.data.meshes.new('三层到达梯');mesh.from_pydata(vertices.tolist(),[],faces.tolist());mesh.update()
                mesh.materials.append(bpy.data.materials[s['material']]);obj=bpy.data.objects.new('三层到达梯',mesh);scene.collection.objects.link(obj)
'''+source[end:]
# Source diagrams and interior views are separate runs; hiding an upper floor must not leak to later views.
source=source.replace("if ob.type=='MESH':ob.visible_camera=True", "if ob.type=='MESH':ob.visible_camera=True;ob.hide_render=False")
source=source.replace("elif name.startswith('bathroom-night'):look(plan(5.38,12.67,5.48),plan(6.2,14.3,5.15),18)","elif name.startswith('bathroom-night'):look(plan(4.55,13.0,5.48),plan(4.1,15.5,5.0),18)")
exec(compile(source,str(script),'exec'))
