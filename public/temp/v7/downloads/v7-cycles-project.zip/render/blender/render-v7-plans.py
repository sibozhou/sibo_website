"""v7 review views, using the actual imported new-plan geometry."""
from pathlib import Path
import os
import sys

os.environ['QIDONG_VIEWER_VERSION']='v7'
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
assert args and all(a in ['front-day','north-day','front-night','north-night','floor1-day','floor2-day','floor3-day',
                         'roof-day','south-elevation-day','west-elevation-day','east-elevation-day'] for a in args)
assert 'floor3-day' not in args or len(args)==1,'Render the third floor in a separate Blender process'
script=Path(__file__).with_name('render.py')
source=script.read_text()
start=source.index("    elif name.startswith('floor2'):")
assert source.count("if ob.type=='MESH':ob.visible_camera=True")==1
end=source.index("    elif name.startswith('west-day'):",start)
source=source[:start]+'''    elif name in ('roof-day','south-elevation-day','west-elevation-day','east-elevation-day'):
        # Clear cars, foliage and landscape props from the drawing comparison.
        # The floor groups still contain the building, plinth and entrance steps.
        for collection in bpy.data.collections:
            if collection.name.startswith('场景_0-'):
                for ob in collection.objects:ob.hide_render=True
        backdrop.location.z=D['model']['vertical']['outdoorLevel']-.001
        backdrop.data.materials[0]=review_ground
        if name=='roof-day':
            scene.camera.location=plan(15.1,8.35,50);scene.camera.rotation_euler=(0,0,angle)
        elif name=='south-elevation-day':
            look(plan(15.1,-44,6.4),plan(15.1,8.35,6.4))
        else:
            camera_x=-44 if name=='west-elevation-day' else 74
            look(plan(camera_x,8.35,5.8),plan(15.1,8.35,5.8))
        side=name in ('west-elevation-day','east-elevation-day')
        scene.camera.data.type='ORTHO';scene.camera.data.ortho_scale=21 if side else 34
        scene.render.resolution_x=1600;scene.render.resolution_y=1020 if side else 1100 if name=='roof-day' else 840
    elif name.startswith('floor'):
        level=int(name[5]);scene.camera.location=plan(15.1,8.35,42)
        scene.camera.rotation_euler=(0,0,angle);scene.camera.data.type='ORTHO';scene.camera.data.ortho_scale=34
        scene.render.resolution_x=1600;scene.render.resolution_y=1100
        for ob in bpy.data.objects:
            if ob.type!='MESH':continue
            group=ob.users_collection[0].name.removeprefix('场景_') if ob.users_collection else ''
            parts=group.split('-')
            if (parts[0].isdigit() and int(parts[0])>level) or ob.get('屋面') or 'ceiling' in group:
                ob.hide_render=True
            if level==3 and parts[0].isdigit() and 0<int(parts[0])<3:ob.hide_render=True
        if level==3:
            # Show the actual arriving stair, without exposing the lower floor's bedrooms through roof voids.
            import numpy as np
            raw=(OUT/'scene.bin').read_bytes();by_id={s['id']:s for s in D['meshes']}
            for sid in sorted({a['source'] for a in D['aliases']}):
                s=by_id[sid]
                if s['level']!=2:continue
                def array(meta,dtype):return np.frombuffer(raw,dtype=dtype,count=meta['bytes']//np.dtype(dtype).itemsize,offset=meta['offset'])
                vertices=array(s['positions'],'<f4').reshape(-1,3).astype(float)
                matrix=np.array(s['matrix']).reshape(4,4).T;vertices=vertices@matrix[:3,:3].T+matrix[:3,3]
                vertices=vertices[:,[0,2,1]]*np.array([1,-1,1]);faces=array(s['indices'],'<u4').reshape(-1,3)
                mesh=bpy.data.meshes.new('三层到达梯');mesh.from_pydata(vertices.tolist(),[],faces.tolist());mesh.update()
                mesh.materials.append(bpy.data.materials[s['material']]);obj=bpy.data.objects.new('三层到达梯',mesh);scene.collection.objects.link(obj)
'''+source[end:]
# The arrival mesh added above is only needed for this view.
source=source.replace("if ob.type=='MESH':ob.visible_camera=True", "if ob.type=='MESH':ob.visible_camera=True;ob.hide_render=False")
source=source.replace("for name in args:", """review_ground=bpy.data.materials.new('图纸对照地面')
review_ground.diffuse_color=(.62,.62,.60,1)
for name in args:
    backdrop.location.z=-.51;backdrop.data.materials[0]=bpy.data.materials['field0']""")
exec(compile(source,str(script),'exec'))
