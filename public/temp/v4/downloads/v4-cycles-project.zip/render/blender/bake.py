import bpy,json,sys,math
import numpy as np
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from denoise import denoise_lightmap
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'output/blender';DEST=OUT/'baked';DEST.mkdir(exist_ok=True)
manifest=json.loads((OUT/'bake-manifest.json').read_text());scene=bpy.context.scene
prefs=bpy.context.preferences.addons['cycles'].preferences;prefs.compute_device_type='METAL';prefs.get_devices()
for device in prefs.devices:device.use=device.type=='METAL'
scene.cycles.device='GPU'
scene.cycles.samples=192;scene.cycles.use_denoising=False;scene.render.bake.target='IMAGE_TEXTURES';scene.render.bake.use_clear=True;scene.render.bake.margin=1
selected=set(sys.argv[sys.argv.index('--')+1:]) if '--' in sys.argv else set()
scene.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.09,.13,.22,1);scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.12
for ob in bpy.data.collections['实际灯具光源'].objects:ob.hide_render=False
uv_chunks=[];offset=0
for group in manifest['groups']:
    ob=bpy.data.objects[group['object']];mesh=ob.data
    bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
    mesh.uv_layers.active_index=1;mesh.uv_layers[1].active_render=True
    size=group['resolution'];image=bpy.data.images.new('光照_'+group['id'],width=size,height=size,alpha=True,float_buffer=True);image.colorspace_settings.name='Non-Color'
    for mat in mesh.materials:
        nodes=mat.node_tree.nodes;tex=nodes.get('烘焙目标') or nodes.new('ShaderNodeTexImage');tex.name='烘焙目标';tex.image=image;nodes.active=tex
    if not selected or group['id'] in selected:
        print('开始Cycles烘焙',group['id'],flush=True)
        bpy.ops.object.bake(type='DIFFUSE',pass_filter={'DIRECT','INDIRECT'},use_selected_to_active=False,uv_layer='照明UV')
        pixels=np.array(image.pixels[:],dtype=np.float32).reshape(size,size,4)
        rgb=denoise_lightmap(np.maximum(0,pixels[:,:,:3]));maximum=np.maximum(rgb.max(axis=2),1e-8)
        pixels[:,:,:3]=rgb;image.pixels.foreach_set(pixels.ravel());np.save(DEST/(group['id']+'.npy'),rgb)
        image.filepath_raw=str(DEST/(group['id']+'.hdr'));image.file_format='HDR';image.save()
        group['irradianceMedian']=float(np.median(maximum[maximum>1e-6]));group['format']='HDR';group['denoised']=True
        print('烘焙完成',group['id'],'中位亮度',group['irradianceMedian'],flush=True)
    uv=np.empty(len(mesh.loops)*2,dtype=np.float32);mesh.uv_layers[1].data.foreach_get('uv',uv)
    group['uvOffset']=offset;group['uvBytes']=uv.nbytes;group['texture']=group['id']+'.hdr';uv_chunks.append(uv.tobytes());offset+=uv.nbytes
    bpy.data.images.remove(image)
(DEST/'uv.bin').write_bytes(b''.join(uv_chunks));(DEST/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False))
print('全部Cycles光照贴图完成',offset,'字节UV',flush=True)
