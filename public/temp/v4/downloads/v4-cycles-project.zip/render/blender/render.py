import os
import bpy,sys,json,math
from pathlib import Path
from mathutils import Vector,Matrix
ROOT=Path(__file__).resolve().parents[2];VERSION=os.environ.get('QIDONG_VIEWER_VERSION','v4');OUT=ROOT/'output/blender' if VERSION=='v4' else ROOT/'output/blender'/VERSION
D=json.loads((OUT/'scene.json').read_text());scene=bpy.context.scene
prefs=bpy.context.preferences.addons['cycles'].preferences;prefs.compute_device_type='METAL';prefs.get_devices()
for device in prefs.devices:device.use=device.type=='METAL'
scene.cycles.device='GPU'
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['bedroom-night']
angle=math.radians(180-D['model']['context']['frontBearing'])
def plan(x,y,z):return Matrix.Rotation(angle,3,'Z')@Vector((x-14.8,y-8.35,z))
def look(position,target,lens=26):
    scene.camera.data.type='PERSP';scene.camera.location=position;scene.camera.rotation_euler=(Vector(target)-scene.camera.location).to_track_quat('-Z','Y').to_euler();scene.camera.data.lens=lens;scene.camera.data.clip_start=.05
for name in args:
    for ob in bpy.data.objects:
        if ob.type=='MESH':ob.visible_camera=True
        if ob.get('diningVariant'):ob.hide_render=ob['diningVariant']!=('festival' if name.startswith('dining-open') else 'daily')
    scene.render.resolution_x=1200;scene.render.resolution_y=800;scene.cycles.samples=32
    if name.startswith('bedroom-night'):look(plan(3.0,12.95,5.43),plan(.9,15.4,5.05),21)
    elif name.startswith('living-night'):look(plan(7.15,4.9,1.58),plan(4.4,3.05,1.15),24)
    elif name.startswith('courtyard-night'):look(plan(14.8,2.0,1.70),plan(14.8,9.5,2.1),24)
    elif name.startswith('dining-open'):look(plan(14.8,12.0,1.65),plan(14.8,15.5,1.3),18)
    elif name.startswith('floor2'):
        look(Vector((0,-13,42)),Vector((0,0,3.9)),34);scene.camera.data.type='ORTHO';scene.camera.data.ortho_scale=40
        scene.render.resolution_x=1440;scene.render.resolution_y=880
        for coll in bpy.data.collections:
            for ob in coll.objects:
                if ob.type=='MESH' and ('3-' in coll.name or 'seamRoof' in ob.name):ob.visible_camera=False
    elif name.startswith('north'):look(Vector((-17,43,15)),Vector((0,0,4.5)),34)
    else:look(Vector((15,-39,16)),Vector((0,0,4.4)),34)
    day=name.endswith('day')
    scene.view_settings.exposure=1.3 if name.startswith(('front-night','north-night','courtyard-night')) else 0
    for ob in bpy.data.collections['实际灯具光源'].objects:ob.hide_render=day
    nodes=scene.world.node_tree.nodes;links=scene.world.node_tree.links;bg=nodes['Background']
    for link in list(bg.inputs['Color'].links):links.remove(link)
    if day:
        s=D['sun'];sky=nodes.get('日光天空') or nodes.new('ShaderNodeTexSky');sky.name='日光天空';sky.sky_type='NISHITA';sky.sun_disc=False;sky.sun_elevation=math.asin(s['up']);sky.sun_rotation=math.atan2(s['north'],s['east']);sky.altitude=120
        links.new(sky.outputs[0],bg.inputs['Color']);bg.inputs['Strength'].default_value=.45
        sun=bpy.data.objects['太阳'];sun.data.energy=3;sun.data.angle=math.radians(.53);sun.rotation_euler=(-Vector((s['east'],s['north'],s['up']))).to_track_quat('-Z','Y').to_euler()
    else:bg.inputs['Color'].default_value=(.09,.13,.22,1);bg.inputs['Strength'].default_value=.12;bpy.data.objects['太阳'].data.energy=0
    if name.endswith('test'):scene.render.resolution_percentage=50;scene.cycles.samples=16
    else:scene.render.resolution_percentage=100
    scene.render.filepath=str(OUT/(name+'.png'));bpy.ops.render.render(write_still=True)
    print('完成图像',name,flush=True)
