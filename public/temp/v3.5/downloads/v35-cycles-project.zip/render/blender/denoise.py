"""Use Blender's bundled Open Image Denoise HDR filter on lightmap bakes."""
import ctypes as C
from pathlib import Path
import numpy as np
import bpy

def denoise_lightmap(rgb):
    library=Path(bpy.app.binary_path).parent.parent/'Resources/lib/libOpenImageDenoise.dylib'
    oidn=C.CDLL(str(library));ptr=C.c_void_p
    def api(name,result,args):
        f=getattr(oidn,name);f.restype=result;f.argtypes=args;return f
    new_device=api('oidnNewDevice',ptr,[C.c_int]);commit_device=api('oidnCommitDevice',None,[ptr])
    new_filter=api('oidnNewFilter',ptr,[ptr,C.c_char_p]);commit_filter=api('oidnCommitFilter',None,[ptr]);execute=api('oidnExecuteFilter',None,[ptr])
    set_image=api('oidnSetSharedFilterImage',None,[ptr,C.c_char_p,ptr,C.c_int,C.c_size_t,C.c_size_t,C.c_size_t,C.c_size_t,C.c_size_t])
    get_error=api('oidnGetDeviceError',C.c_int,[ptr,C.POINTER(C.c_char_p)])
    release_filter=api('oidnReleaseFilter',None,[ptr]);release_device=api('oidnReleaseDevice',None,[ptr])
    device=new_device(1);commit_device(device);f=new_filter(device,b'RT')
    set_bool=api('oidnSetFilterBool',None,[ptr,C.c_char_p,C.c_bool]);set_bool(f,b'hdr',True)
    data=np.ascontiguousarray(rgb,dtype=np.float32);result=np.empty_like(data);height,width=data.shape[:2]
    set_image(f,b'color',data.ctypes.data,3,width,height,0,0,0);set_image(f,b'output',result.ctypes.data,3,width,height,0,0,0)
    commit_filter(f);execute(f);message=C.c_char_p();error=get_error(device,C.byref(message))
    text=message.value.decode() if message.value else ''
    release_filter(f);release_device(device)
    if error:raise RuntimeError(text)
    return np.maximum(0,result)

if __name__=='__main__':
    root=Path(__file__).resolve().parents[2]/'output/blender/baked'
    image=bpy.data.images.load(str(root/'2-A.hdr'));w,h=image.size;p=np.array(image.pixels[:],dtype=np.float32).reshape(h,w,4)
    p[:,:,:3]=denoise_lightmap(p[:,:,:3]);image.pixels.foreach_set(p.ravel());image.filepath_raw=str(root/'2-A.hdr');image.file_format='HDR';image.save();print('HDR光照贴图降噪完成')
