import os
"""Build a reproducible Cycles scene from the current viewer's actual geometry."""
import bpy, json, math, sys
import numpy as np
from pathlib import Path
from mathutils import Vector, Matrix

ROOT=Path(__file__).resolve().parents[2]
VERSION=os.environ.get('QIDONG_VIEWER_VERSION','v4');OUT=ROOT/'output/blender' if VERSION=='v4' else ROOT/'output/blender'/VERSION
D=json.loads((OUT/'scene.json').read_text())
RAW=(OUT/'scene.bin').read_bytes()
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=True
scene.cycles.max_bounces=8;scene.cycles.diffuse_bounces=6;scene.cycles.glossy_bounces=4;scene.cycles.transmission_bounces=8
prefs=bpy.context.preferences.addons['cycles'].preferences
prefs.compute_device_type='METAL';prefs.get_devices()
for device in prefs.devices:device.use=device.type=='METAL'
scene.cycles.device='GPU'
scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
scene.tool_settings.use_uv_select_sync=True
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=0
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB'
scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.09,.13,.22,1)
scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.12
scene['说明']='现有v4实际网格导入；灯具处的真实面光/聚光参与Cycles多次反射；渲染能量不代表施工采购功率。'
scene['模型校验']=D['sourceHash']

def arr(meta,dtype):return np.frombuffer(RAW,dtype=dtype,count=meta['bytes']//np.dtype(dtype).itemsize,offset=meta['offset'])
def linhex(s):
    rgb=[int(s.lstrip('#')[i:i+2],16)/255 for i in (0,2,4)]
    return tuple(x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in rgb)
def material(name,spec):
    mat=bpy.data.materials.new(name);mat.use_nodes=True
    nodes=mat.node_tree.nodes;links=mat.node_tree.links;p=nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=(*spec['color'],1);p.inputs['Roughness'].default_value=spec['roughness'];p.inputs['Metallic'].default_value=spec['metalness']
    if spec['transparent']:
        p.inputs['Transmission Weight'].default_value=1;p.inputs['IOR'].default_value=1.45;p.inputs['Roughness'].default_value=.36 if name=='frost' else .045
        if name=='glass':p.inputs['Base Color'].default_value=(.91,.96,.98,1)
        if D['model'].get('glazing',{}).get('untinted') and name in ('glass','frost','guardGlass'):p.inputs['Base Color'].default_value=(1,1,1,1)
    if name in ('warmGlow','taskGlow','lampShade'):
        lightpath=nodes.new('ShaderNodeLightPath');em=nodes.new('ShaderNodeEmission');mix=nodes.new('ShaderNodeMixShader')
        em.inputs['Color'].default_value=(1,.72,.43,1) if name!='taskGlow' else (1,.82,.6,1)
        em.inputs['Strength'].default_value=8 if name!='lampShade' else 1.2
        links.new(lightpath.outputs['Is Camera Ray'],mix.inputs[0]);links.new(p.outputs[0],mix.inputs[1]);links.new(em.outputs[0],mix.inputs[2]);links.new(mix.outputs[0],nodes.get('Material Output').inputs['Surface'])
    if name=='wall':
        noise=nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=110
        bump=nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.12;bump.inputs['Distance'].default_value=.0012
        links.new(noise.outputs['Fac'],bump.inputs['Height']);links.new(bump.outputs['Normal'],p.inputs['Normal'])
    finish=spec['finish']
    if finish:
        uv=nodes.new('ShaderNodeUVMap');uv.uv_map='材质UV'
        if finish['pattern']=='oak':
            mapping=nodes.new('ShaderNodeVectorMath');mapping.operation='MULTIPLY';mapping.inputs[1].default_value=(45,2,1)
            noise=nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=2.5;noise.inputs['Detail'].default_value=2
            ramp=nodes.new('ShaderNodeValToRGB');c=np.array(linhex(finish['color']))
            ramp.color_ramp.elements[0].color=(*tuple(c*.91),1);ramp.color_ramp.elements[1].color=(*tuple(c*1.06),1)
            links.new(uv.outputs[0],mapping.inputs[0]);links.new(mapping.outputs[0],noise.inputs[0]);links.new(noise.outputs['Fac'],ramp.inputs[0]);links.new(ramp.outputs[0],p.inputs['Base Color'])
        else:
            brick=nodes.new('ShaderNodeTexBrick');brick.offset=0;brick.inputs['Scale'].default_value=1
            brick.inputs['Brick Width'].default_value=finish['size'][0];brick.inputs['Row Height'].default_value=finish['size'][1]
            brick.inputs['Mortar Size'].default_value=.003;brick.inputs['Mortar Smooth'].default_value=.001
            c=np.array(linhex(finish['color']));brick.inputs['Color1'].default_value=(*tuple(c*.98),1);brick.inputs['Color2'].default_value=(*tuple(c*1.02),1);brick.inputs['Mortar'].default_value=(*linhex(finish['grout']),1)
            links.new(uv.outputs[0],brick.inputs['Vector']);links.new(brick.outputs['Color'],p.inputs['Base Color'])
    return mat
MATS={name:material(name,spec) for name,spec in D['materials'].items()}
collections={}
def collection(group):
    if group not in collections:
        c=bpy.data.collections.new('场景_'+group);scene.collection.children.link(c);collections[group]=c
    return collections[group]
def world_arrays(s):
    p=arr(s['positions'],'<f4').reshape(-1,3).astype(np.float64);n=arr(s['normals'],'<f4').reshape(-1,3)
    matrix=np.array(s['matrix']).reshape(4,4).T
    p=p@matrix[:3,:3].T+matrix[:3,3]
    n=n@np.linalg.inv(matrix[:3,:3]);n/=np.linalg.norm(n,axis=1)[:,None]
    # Three.js Y up -> Blender Z up; keep north at positive Y.
    return p[:,[0,2,1]]*np.array([1,-1,1]),n[:,[0,2,1]]*np.array([1,-1,1])

groups={}
for s in D['meshes']:
    # Keep roofs, glass and visible emitters separate from lightmap receivers.
    key=(s['group'] if s['bakeable'] else 'extra-'+s['group']+'-'+s['material'])+('-'+s['variant'] if s.get('variant') else '')
    groups.setdefault(key,[]).append(s)
manifest={'sourceHash':D['sourceHash'],'groups':[],'meshes':[],'aliases':D['aliases'],'bakeState':'联厅隔断完全移开'}
for key,items in groups.items():
    verts=[];faces=[];uvs=[];normals=[];face_material=[];slots=[];base=0;loops=0
    for s in items:
        p,n=world_arrays(s);idx=arr(s['indices'],'<u4').reshape(-1,3);uv=arr(s['uv'],'<f4').reshape(-1,2)
        verts.append(p);faces.append(idx+base);uvs.append(uv[idx].reshape(-1,2));normals.append(n[idx].reshape(-1,3))
        if s['material'] not in slots:slots.append(s['material'])
        face_material.extend([slots.index(s['material'])]*len(idx))
        if not key.startswith('extra-'):manifest['meshes'].append({'id':s['id'],'group':key,'start':loops,'count':len(idx)*3,'vertices':s['vertices'],'triangles':s['triangles']})
        base+=len(p);loops+=len(idx)*3
    mesh=bpy.data.meshes.new(key);mesh.from_pydata(np.concatenate(verts).tolist(),[],np.concatenate(faces).tolist());mesh.update()
    for name in slots:mesh.materials.append(MATS[name])
    for poly,mi in zip(mesh.polygons,face_material):poly.material_index=mi;poly.use_smooth=True
    mesh.normals_split_custom_set(np.concatenate(normals).tolist())
    layer=mesh.uv_layers.new(name='材质UV');layer.data.foreach_set('uv',np.concatenate(uvs).ravel())
    ob=bpy.data.objects.new('网格_'+key,mesh);collection(items[0]['group']).objects.link(ob)
    if items[0].get('variant'):ob['diningVariant']=items[0]['variant'];ob.hide_render=items[0]['variant']=='festival';ob.hide_set(items[0]['variant']=='festival')
    if not key.startswith('extra-'):
        mesh.uv_layers.new(name='照明UV');mesh.uv_layers.active_index=1
        bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
        scene.tool_settings.use_uv_select_sync=False
        bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT')
        print('UV展开',key,flush=True)
        bpy.ops.uv.smart_project(angle_limit=math.radians(66),island_margin=.007,margin_method='SCALED',area_weight=.5,correct_aspect=True)
        scene.tool_settings.use_uv_select_sync=True
        bpy.ops.uv.select_all(action='SELECT')
        bpy.ops.uv.average_islands_scale()
        print('UV排布',key,flush=True)
        bpy.ops.uv.pack_islands(margin=.0015,margin_method='FRACTION',rotate=True)
        bpy.ops.object.mode_set(mode='OBJECT')
        manifest['groups'].append({'id':key,'object':ob.name,'loops':len(mesh.loops),'resolution':512 if items[0].get('variant') else 1024,'variant':items[0].get('variant')})
    print('导入',key,len(mesh.polygons),'三角形',flush=True)

def to_bl(p):return Vector((p[0],-p[2],p[1]))
lights=bpy.data.collections.new('实际灯具光源');scene.collection.children.link(lights)
for f in D['lights']:
    kind=f['kind'];linear=kind in ('cove','linear','mirror','reading','desk','step','floor','bollard')
    typ='AREA' if linear else 'SPOT';ld=bpy.data.lights.new(f['id']+'_'+kind,typ);ob=bpy.data.objects.new(ld.name,ld);lights.objects.link(ob)
    ob.location=to_bl(f['point']);target=to_bl(f['aim'])
    if kind=='cove':target=ob.location+Vector((0,0,1))
    # Put light just outside the physical diffuser, rather than inside its casing.
    if kind=='reading':
        nx,ny=f['normal'];plan=Vector((nx*.08,ny*.08,0));plan.rotate(Matrix.Rotation(math.radians(180-D['model']['context']['frontBearing']),3,'Z'));ob.location+=plan;ob.location.z-=.075
    elif kind=='floor':ob.location.z-=.17
    elif kind in ('desk','linear','mirror','downlight','pendant'):ob.location.z-=.025 if kind!='desk' else .05
    elif kind=='ground':ob.location.z+=.055
    if kind=='mirror':
        nx,ny=f['normal'];inward=Vector((nx*.055,ny*.055,0));inward.rotate(Matrix.Rotation(math.radians(180-D['model']['context']['frontBearing']),3,'Z'));ob.location+=inward
    else:ob.location+=(target-ob.location).normalized()*(.10 if kind=='sconce' else .025)
    ob.rotation_euler=(target-ob.location).to_track_quat('-Z','Y').to_euler()
    if kind=='step':ob.location+=(target-ob.location).normalized()*.075
    ld.color=(1,.70,.40) if f['temperature']==2700 else (1,.79,.55)
    if typ=='AREA':
        ld.shape='RECTANGLE';ld.size=f.get('length',.18);ld.size_y=.06 if kind=='cove' else .12
        ld.energy={'cove':35*f.get('length',2),'linear':25*f.get('length',1),'mirror':18,'reading':8,'desk':12,'step':1.5,'floor':35,'bollard':12}[kind]
        if kind=='cove':
            # Align the long dimension with the model's actual strip axis.
            normal=f['normal'];plan=Vector((0,1,0)) if normal[0] else Vector((1,0,0));angle=(180-D['model']['context']['frontBearing'])*math.pi/180
            plan.rotate(Matrix.Rotation(angle,3,'Z'));ob.rotation_euler.z=math.atan2(plan.y,plan.x)
        elif kind=='linear' and f.get('zone'):
            normal=f.get('normal',[0,1]);axis=Vector((0,1,0)) if normal[0] else Vector((1,0,0));axis.rotate(Matrix.Rotation(math.radians(180-D['model']['context']['frontBearing']),3,'Z'))
            zaxis=-(target-ob.location).normalized();yaxis=zaxis.cross(axis).normalized();xaxis=yaxis.cross(zaxis).normalized();ob.rotation_euler=Matrix((xaxis,yaxis,zaxis)).transposed().to_euler()
        ld.spread=math.radians(160)
    else:
        ld.energy={'downlight':45,'pendant':60,'sconce':32,'ground':35}.get(kind,25)
        if f['id'].endswith('u'):ld.energy=8
        ld.spot_size=min(math.radians(150),f['angle']*2);ld.spot_blend=.75;ld.shadow_soft_size=.045
    if 'renderPower' in f:ld.energy=f.get('upPower',8) if f['id'].endswith('u') else f['renderPower']
    ob['楼层']=f['level'];ob['住户']=f['home'];ob['灯具编号']=f['id'];ob['房间']=f['room'];ob['说明']='渲染能量，非采购功率'

camd=bpy.data.cameras.new('建筑镜头');cam=bpy.data.objects.new('建筑镜头',camd);scene.collection.objects.link(cam);scene.camera=cam;camd.lens=30
cam.location=(15,-39,16);cam.rotation_euler=(Vector((0,0,4.4))-cam.location).to_track_quat('-Z','Y').to_euler()
sun_data=bpy.data.lights.new('太阳','SUN');sun=bpy.data.objects.new('太阳',sun_data);scene.collection.objects.link(sun);sun.rotation_euler=(math.radians(28),math.radians(-25),math.radians(-30));sun_data.energy=0;sun_data.angle=math.radians(4)
scene.render.resolution_x=1200;scene.render.resolution_y=800;scene.render.resolution_percentage=100
(OUT/'bake-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False))
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/f'祁东双户住宅_{VERSION}_Cycles.blend'))
print('工程已保存',len(manifest['groups']),'照明组',len(D['lights']),'实际位置光源',flush=True)
