"""v5 service-door camera and daylight cutaway; the v4 renderer is unchanged."""
from pathlib import Path
import os
import sys

os.environ['QIDONG_VIEWER_VERSION'] = 'v5'
args = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
assert len(args) == 1 and args[0] in ['service-north-day', 'floor2-day']
script = Path(__file__).with_name('render.py')
source = script.read_text().replace(
    "look(plan(5.1,23.0,6.0),plan(5.1,14.9,5.7),21)",
    "look(plan(6.2,23.4,2.3),plan(5.1,16.7,1.7),25)")
if args[0] == 'floor2-day':
    # A diagram with the upper floor removed must also admit daylight there.
    source = source.replace('ob.visible_camera=False', 'ob.hide_render=True')
exec(compile(source, str(script), 'exec'))
