import os
import bpy,sys,json,math
from pathlib import Path
from mathutils import Vector,Matrix
ROOT=Path(__file__).resolve().parents[2];VERSION=os.environ.get('QIDONG_VIEWER_VERSION','v4');OUT=ROOT/'output/blender' if VERSION=='v4' else ROOT/'output/blender'/VERSION
D=json.loads((OUT/'scene.json').read_text());scene=bpy.context.scene
prefs=bpy.context.preferences.addons['cycles'].preferences;prefs.compute_device_type='METAL';prefs.get_devices()
for device in prefs.devices:device.use=device.type=='METAL'
scene.cycles.device='GPU'
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['bedroom-night']
angle=math.radians(180-D['model']['context']['frontBearing'])
def plan(x,y,z):return Matrix.Rotation(angle,3,'Z')@Vector((x-14.8,y-8.35,z))
def look(position,target,lens=26):
    scene.camera.data.type='PERSP';scene.camera.location=position;scene.camera.rotation_euler=(Vector(target)-scene.camera.location).to_track_quat('-Z','Y').to_euler();scene.camera.data.lens=lens;scene.camera.data.clip_start=.05
def garden_season(day):
    def smooth(a,b,v):
        t=max(0,min(1,(v-a)/(b-a)));return t*t*(3-2*t)
    def pulse(a,b,fade=18):return smooth(a,a+fade,day)*(1-smooth(b-fade,b,day))
    return dict(leaf=pulse(65,340,35),autumn=pulse(265,338,22),winter=1-pulse(65,330,30),crape=pulse(155,266,22),gardenia=pulse(135,207,18),azalea=pulse(65,145,20),camellia=max(pulse(-30,105,20),pulse(315,470,20)),osmanthus=pulse(252,303,14))
garden=D['model'].get('arrivalGarden',{});palette=garden.get('species',{});deciduous={'crape'}|{key for key,spec in palette.items() if spec.get('deciduous')}
centers_by_species={'crape':[plan(*t['point'],D['model']['vertical']['outdoorLevel']+2.75) for t in garden.get('trees',[])]}
for key in deciduous-{'crape'}:centers_by_species[key]=[plan(*t['point'],D['model']['vertical']['outdoorLevel']+t['height']*.72) for t in garden.get('estate',{}).get('trees',[]) if t['species']==key]
canopy_vertices=[]
for ob in bpy.data.objects:
    if ob.type!='MESH':continue
    for key in deciduous:
        slots={i for i,slot in enumerate(ob.material_slots) if slot.material and slot.material.name in ('gardenLeaf_'+key,'gardenBloom_'+key)}
        indices={i for poly in ob.data.polygons if poly.material_index in slots for i in poly.vertices};centers=centers_by_species.get(key,[])
        for i in indices:
            co=ob.data.vertices[i].co.copy()
            if centers:canopy_vertices.append((ob,i,co,min(centers,key=lambda c:(c-co).length)))
def plant_colors(day):
    def color(h):
        rgb=[int(h.lstrip('#')[i:i+2],16)/255 for i in (0,2,4)]
        return [v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in rgb]
    def mix(a,b,t):return [x+(y-x)*t for x,y in zip(a,b)]
    p=garden_season(day)
    ratio=(.05+.95*p['leaf'])/(.05+.95*garden_season(302)['leaf'])
    for ob,i,co,center in canopy_vertices:ob.data.vertices[i].co=center+(co-center)*ratio
    for key,spec in D['model'].get('arrivalGarden',{}).get('species',{}).items():
        leaf=color(spec['leaf'])
        if key=='crape':leaf=mix(leaf,color('#b88a4b'),p['autumn']*.85)
        if key=='nandina':leaf=mix(leaf,color('#9a6552'),p['winter']*.8+p['autumn']*.4)
        if spec.get('autumn'):leaf=mix(leaf,color(spec['autumn']),p['autumn']*.95)
        if key=='azalea':leaf=mix(leaf,color('#645f46'),p['winter']*.25)
        for prefix,c in [('gardenLeaf_',leaf),('gardenBloom_',mix(leaf,color(spec.get('bloom',spec['leaf'])),p.get(key,0)))]:
            mat=bpy.data.materials.get(prefix+key)
            if not mat:continue
            nodes=mat.node_tree.nodes;links=mat.node_tree.links;shader=nodes.get('Principled BSDF');shader.inputs['Base Color'].default_value=(*c,1)
            if key in deciduous:
                transparent=nodes.get('落叶季透明') or nodes.new('ShaderNodeBsdfTransparent');transparent.name='落叶季透明'
                links.new((transparent if p['leaf']<=.015 else shader).outputs[0],nodes.get('Material Output').inputs['Surface'])
    for name,base,winter,weight in [('estateGrass','#85956f','#b3a77e',min(1,p['winter']*.85+p['autumn']*.3)),('estateMeadow','#929c7d','#aaa48a',p['winter']*.55)]:
        mat=bpy.data.materials.get(name)
        if mat:mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(*mix(color(base),color(winter),weight),1)
# Neutral camera-only ground beyond the satellite context prevents a black horizon edge.
bpy.ops.mesh.primitive_plane_add(size=1000,location=(0,0,-.51));backdrop=bpy.context.object;backdrop.name='远景背景（非设计用地）';backdrop.data.materials.append(bpy.data.materials['field0']);backdrop.visible_diffuse=False;backdrop.visible_glossy=False;backdrop.visible_shadow=False;backdrop.visible_transmission=False
for name in args:
    season=next((s for s in ['spring','summer','autumn','winter'] if name.startswith('garden-'+s+'-')),None)
    plant_colors(dict(spring=100,summer=195,autumn=285,winter=20).get(season,302))
    for ob in bpy.data.objects:
        if ob.type=='MESH':ob.visible_camera=True
        if ob.get('diningVariant'):ob.hide_render=ob['diningVariant']!=('festival' if name.startswith('dining-open') else 'daily')
    scene.render.resolution_x=1800 if name.startswith(('arrival-','garden-','estate-','pavilion-')) else 1200;scene.render.resolution_y=1200 if name.startswith(('arrival-','garden-','estate-','pavilion-')) else 800;scene.cycles.samples=48 if name.startswith(('arrival-','garden-','estate-','pavilion-')) else 32
    if name.startswith('arrival-'):look(plan(-12,-48,32),plan(-2,1.2,1),30)
    elif name.startswith(('estate-','garden-')):look(plan(75,-38,58),plan(23,10,2),40)
    elif name.startswith('pavilion-'):look(plan(48.9,7.4,1.25),plan(43.0,12.4,.8),26)
    elif name.startswith('stair3-'):look(plan(8.0,11.9,8.95),plan(5.2,10.0,7.8),22)
    elif name.startswith('stair-pair-'):look(plan(14.8,9.85,5.75),plan(4.8,9.85,5.75),35)
    elif name.startswith('stairs-'):look(plan(7.85,9.8,1.65),plan(4.2,9.8,2.0),21)
    elif name.startswith('terrace-'):look(plan(11.8,.30,5.65),plan(8.8,3.25,4.45),21)
    elif name.startswith('bedroom-night'):look(plan(3.0,12.95,5.43),plan(.9,15.4,5.05),21)
    elif name.startswith('living-night'):look(plan(7.15,4.9,1.58),plan(4.4,3.05,1.15),24)
    elif name.startswith('media-night'):look(plan(22.2,16.05,8.75),plan(17.5,12.2,8.4),20)
    elif name.startswith('bathroom-night'):look(plan(5.38,12.67,5.48),plan(6.2,14.3,5.15),18)
    elif name.startswith('courtyard-day'):look(plan(16.2,10.7,1.75),plan(14.8,6.0,1.15),21)
    elif name.startswith('courtyard-night'):look(plan(16.2,10.7,1.75),plan(14.8,6.0,1.15),21)
    elif name.startswith('dining-open'):look(plan(14.8,12.0,1.65),plan(14.8,15.5,1.3),18)
    elif name.startswith('floor2'):
        look(Vector((0,-13,42)),Vector((0,0,3.9)),34);scene.camera.data.type='ORTHO';scene.camera.data.ortho_scale=40
        scene.render.resolution_x=1440;scene.render.resolution_y=880
        for coll in bpy.data.collections:
            for ob in coll.objects:
                if ob.type=='MESH' and ('3-' in coll.name or 'seamRoof' in ob.name or 'ceiling' in coll.name):ob.visible_camera=False
    elif name.startswith('west-day'):look(Vector((-45,-8,14)),Vector((0,0,4.5)),34)
    elif name.startswith('east-day'):look(Vector((45,-8,14)),Vector((0,0,4.5)),34)
    elif name.startswith('service-north-day'):look(plan(5.1,23.0,6.0),plan(5.1,14.9,5.7),21)
    elif name.startswith('north'):look(Vector((-17,43,15)),Vector((0,0,4.5)),34)
    else:look(Vector((15,-39,16)),Vector((0,0,4.4)),34)
    day=name.endswith('day')
    scene.view_settings.exposure=(2.0 if name.endswith('day') else .4) if name.startswith(('stairs-','stair3-')) else 1.3 if name.startswith(('front-night','north-night','courtyard-night')) else 0
    if name=='arrival-night':scene.view_settings.exposure=1.0
    if name=='estate-night':scene.view_settings.exposure=1.3
    if name=='pavilion-night':scene.view_settings.exposure=.9
    for ob in bpy.data.collections['实际灯具光源'].objects:ob.hide_render=day
    nodes=scene.world.node_tree.nodes;links=scene.world.node_tree.links;bg=nodes['Background']
    for link in list(bg.inputs['Color'].links):links.remove(link)
    if day:
        s=D.get('seasonSuns',{}).get(season,D['sun']);sky=nodes.get('日光天空') or nodes.new('ShaderNodeTexSky');sky.name='日光天空';sky.sky_type='NISHITA';sky.sun_disc=False;sky.sun_elevation=math.asin(s['up']);sky.sun_rotation=math.atan2(s['north'],s['east']);sky.altitude=120
        links.new(sky.outputs[0],bg.inputs['Color']);bg.inputs['Strength'].default_value=.45
        sun=bpy.data.objects['太阳'];sun.data.energy=3;sun.data.angle=math.radians(.53);sun.rotation_euler=(-Vector((s['east'],s['north'],s['up']))).to_track_quat('-Z','Y').to_euler()
    else:bg.inputs['Color'].default_value=(.09,.13,.22,1);bg.inputs['Strength'].default_value=.12;bpy.data.objects['太阳'].data.energy=0
    if name.endswith('test'):scene.render.resolution_percentage=50;scene.cycles.samples=16
    else:scene.render.resolution_percentage=100
    scene.render.filepath=str(OUT/(name+'.png'));bpy.ops.render.render(write_still=True)
    print('完成图像',name,flush=True)
